console.log('Loading function');

export const handler = async (event, context) => {
    return 'hello Another Welcome Message from YS Academy';
};